import numpy as np
import csv
import matplotlib.pyplot as plt
from scipy.cluster import hierarchy

def load_data(filepath):
    reader = csv.DictReader(open(filepath, 'rt'))
    dict_list = []
    for line in reader:
        dict_list.append(line)
    dict_list
    return dict_list

def calc_features(row):
    x_1 = row['Attack']
    x_2 = row['Sp. Atk']
    x_3 = row['Speed']
    x_4 = row['Defense']
    x_5 = row['Sp. Def']
    x_6 = row['HP']
    array = np.array([x_1, x_2, x_3, x_4, x_5, x_6], dtype = np.int64)
    return array

def hac(features):
    n = len(features)
    index = list(range(n))
    array = np.empty((n-1,4))
    # view each feature as one cluster
    features = [[cluster] for cluster in features]
    for i in range(n-1):
        # set some variables
        min_distance = 999999
        # determine which two clusters should be merged
        for c1 in index:
            for c2 in index:
                if c2 > c1:
                    max_distance = 0
                    for x in features[c1]:
                        for y in features[c2]:
                            distance = np.linalg.norm(y-x)
                            if distance > max_distance:
                                max_distance = distance
                    if max_distance < min_distance:
                        min_distance = max_distance
                        cluster1 = c1
                        cluster2 = c2
        # merge two clusters
        new_cluster = features[cluster1] + features[cluster2]
        # append this new clusters to features
        features.append(new_cluster)
        index.append(n+i)
        index.remove(cluster1)
        index.remove(cluster2)
        array[i][0] = cluster1
        array[i][1] = cluster2
        array[i][2] = min_distance
        array[i][3] = len(new_cluster)
    return array

def imshow_hac(Z):
    hierarchy.dendrogram(Z)
    plt.show()