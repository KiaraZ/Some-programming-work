if __name__ =="__main__":
    import numpy as np
    import csv
    import matplotlib.pyplot as plt
    import sys
    # read csv file
    with open(sys.argv[1], mode = 'r') as csv_file:
        reader = csv.reader(csv_file)
        rows = []
        for item in reader:
            rows.append(item)
    # create the vectors of year and days
    data = rows[1:]
    year = []
    days = []
    for i in data:
        year.append(int(i[0]))
        days.append(int(i[1]))
    # plot the data
    plt.plot(year, days)
    plt.xlabel('Year')
    plt.ylabel('Number of frozen days')
    plt.savefig("plot.png")

    # question 3: linear regression
    X = np.arange(2*len(year)).reshape(len(year), 2)
    for i in range(len(year)):
        X[i][0] = 1
        X[i][1] = year[i]
    Y = np.arange(len(days))
    for i in range(len(days)):
        Y[i] = days[i]
    X_T = np.transpose(X)
    Z = np.dot(X_T,X)
    I = np.linalg.inv(Z)
    PI = np.dot(I,X_T)
    hat_beta = np.dot(PI,Y)

    print("Q3a:")
    print(X)
    print("Q3b:")
    print(Y)
    print("Q3c:")
    print(Z)
    print("Q3d:")
    print(I)
    print("Q3e:")
    print(PI)
    print("Q3f:")
    print(hat_beta)

    # question 4
    x_test = 2021
    y_test = hat_beta[0] + hat_beta[1] * x_test
    print("Q4: " + str(y_test))

    # question 5
    print("Q5a: " + "<")
    print("Q5b: " + "A negative sign of hat_beta_1 means the number of ice days decreases as the year increases.")

    # question 6
    x_star = (0 - hat_beta[0])/hat_beta[1]
    print("Q6a: " + str(x_star))
    print("Q6b: " + "I do think this prediction makes sense because the overall data trend is decreasing, though there were sometimes fluctuations between different years. From the dataset, we can see that the number of ice days in the first decades of years is mostly greater than 100, while the number of ice days in the last decades of years is mostly less than 100 but greater than 0. Therefore, it seems reasonable that after hundreds of years the number of ice days may be 0.")