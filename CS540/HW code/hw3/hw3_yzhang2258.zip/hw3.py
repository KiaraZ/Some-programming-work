from scipy.linalg import eigh
import numpy as np
import matplotlib.pyplot as plt

def load_and_center_dataset(filename):
    x = np.load(filename)
    mean = np.mean(x, axis = 0)
    centered_x = x - mean
    return centered_x

def get_covariance(dataset):
    dataset_t = np.transpose(dataset)
    n = len(dataset)
    S = np.dot(dataset_t, dataset)/(n-1)
    return S

def get_eig(S, m):
    n = len(S)
    eigh_func = eigh(S, subset_by_index = [n-m, n-1])
    values = np.flip(np.diag(eigh_func[0]))
    vectors = np.flip(eigh_func[1], axis = 1)
    return values, vectors

def get_eig_prop(S, prop):
    sum_eig = sum(eigh(S)[0])
    eigh_func = eigh(S, subset_by_value = [sum_eig*prop, np.inf])
    values = np.flip(np.diag(eigh_func[0]))
    vectors = np.flip(eigh_func[1], axis = 1)
    return values, vectors

def project_image(image, U):
    U_t = np.transpose(U)
    a_ij_vec = np.dot(U_t, image)
    projection = np.dot(U, a_ij_vec)
    return projection

def display_image(orig, proj):
    # reshape vectors
    orig_reshape = np.reshape(orig, (32,32))
    proj_reshape = np.reshape(proj, (32,32))
    # create a figure with two subplots
    f, (ax1, ax2) = plt.subplots(ncols = 2, figsize = (8,3))
    # plot 1
    ax1.set_title("Original")
    orig_fig = ax1.imshow(np.transpose(orig_reshape), aspect = 'equal')
    plt.colorbar(orig_fig, ax = ax1)
    # plot 2
    ax2.set_title("Projection")
    proj_fig = ax2.imshow(np.transpose(proj_reshape), aspect = 'equal')
    plt.colorbar(proj_fig, ax = ax2)
